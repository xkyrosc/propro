# ProPrompt

A mobile-first teleprompter app built with React, Vite, and Capacitor. It includes a script library, editor, auto-scrolling reader, speed control, text size/spacing settings, mirror mode, fullscreen, and JSON import/export.

## Requirements
- Node.js 20 or newer
- Android Studio with Android SDK installed
- Java 17 (usually included with current Android Studio)

## Run in a browser
```bash
npm install
npm run dev
```

## Build the Android project
```bash
npm install
npm run android:add
npm run android:sync
npm run android:open
```
In Android Studio, allow Gradle sync to finish, select a debug build variant, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the APK path when complete.

For a command-line debug APK after Android project creation:
```bash
cd android
./gradlew assembleDebug
```
On Windows, use `gradlew.bat assembleDebug`.

The debug APK is for direct testing/sideloading. A Play Store release later needs a signed release build and a Play App Signing-compatible upload package.

## Current limitations
- Scripts are saved in browser/app local storage on this device; clearing app data removes them. Export backups regularly.
- Floating overlay, voice-following, and in-app camera recording are not included in this first version. They need additional native/platform-specific implementation.
- Fullscreen support depends on the Android WebView/device.
- The web font uses Google Fonts when internet is available; system fonts are the fallback.
