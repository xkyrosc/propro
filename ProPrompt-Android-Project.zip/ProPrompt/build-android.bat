@echo off
setlocal
echo === ProPrompt Android Build Helper ===
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install Node.js 20+ and try again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing project dependencies...
  call npm install
  if errorlevel 1 goto fail
)
if not exist android\gradlew.bat (
  echo Creating Android project...
  call npx cap add android
  if errorlevel 1 goto fail
)
echo Syncing app files...
call npm run build
if errorlevel 1 goto fail
call npx cap sync android
if errorlevel 1 goto fail
echo.
echo Opening Android Studio...
call npx cap open android
echo In Android Studio, build an APK via Build ^> Build Bundle(s) / APK(s) ^> Build APK(s).
pause
exit /b 0
:fail
echo.
echo Build preparation failed. Check the error above.
pause
exit /b 1
