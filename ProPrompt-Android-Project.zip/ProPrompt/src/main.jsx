import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Plus, Search, Play, Pause, RotateCcw, Settings2, FileText, Trash2,
  Pencil, ChevronLeft, Type, Minus, Sun, Moon, FlipHorizontal2, Maximize,
  Download, Upload, Clock3, Check, X, MoreHorizontal, SlidersHorizontal
} from 'lucide-react';
import './style.css';

const STARTER = [
  { id: 'welcome', title: 'Welcome to ProPrompt', updated: Date.now(), body: 'Welcome to ProPrompt.\\n\\nYour words, your pace.\\n\\nTake a breath, look at the camera, and speak naturally.\\n\\nUse the speed slider to find a comfortable rhythm. You can pause at any time, or tap anywhere on the script to reposition it.\\n\\nYou are ready to begin.' }
];
const loadScripts = () => {
  try {
    const raw = localStorage.getItem('proprompt-scripts-v1');
    return raw ? JSON.parse(raw) : STARTER;
  } catch { return STARTER; }
};

function App() {
  const [scripts, setScripts] = useState(loadScripts);
  const [activeId, setActiveId] = useState(null);
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState(false);
  const [draftTitle, setDraftTitle] = useState('');
  const [draftBody, setDraftBody] = useState('');
  const [running, setRunning] = useState(false);
  const [speed, setSpeed] = useState(32);
  const [fontSize, setFontSize] = useState(34);
  const [lineHeight, setLineHeight] = useState(1.55);
  const [mirror, setMirror] = useState(false);
  const [dark, setDark] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showTools, setShowTools] = useState(false);
  const [toast, setToast] = useState('');
  const [remaining, setRemaining] = useState(0);
  const scrollRef = useRef(null);
  const frameRef = useRef(null);
  const lastRef = useRef(0);
  const active = scripts.find(s => s.id === activeId);
  const filtered = useMemo(() => scripts.filter(s => s.title.toLowerCase().includes(query.toLowerCase()) || s.body.toLowerCase().includes(query.toLowerCase())), [scripts, query]);

  useEffect(() => { localStorage.setItem('proprompt-scripts-v1', JSON.stringify(scripts)); }, [scripts]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(''), 2400);
    return () => clearTimeout(t);
  }, [toast]);

  useEffect(() => {
    const step = (time) => {
      if (running && scrollRef.current) {
        if (lastRef.current) {
          const delta = Math.min(time - lastRef.current, 50);
          scrollRef.current.scrollTop += (speed / 10) * (delta / 16.67);
        }
        lastRef.current = time;
      } else lastRef.current = 0;
      frameRef.current = requestAnimationFrame(step);
    };
    frameRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frameRef.current);
  }, [running, speed, activeId]);

  useEffect(() => {
    if (!active) return;
    setDraftTitle(active.title);
    setDraftBody(active.body);
    setRunning(false);
  }, [activeId]);

  useEffect(() => {
    if (!active || !scrollRef.current) return;
    scrollRef.current.scrollTop = 0;
  }, [activeId]);

  const notify = (msg) => setToast(msg);
  const openNew = () => {
    setActiveId(null);
    setDraftTitle('');
    setDraftBody('');
    setEditing(true);
  };
  const openEdit = (script) => {
    setActiveId(script.id);
    setDraftTitle(script.title);
    setDraftBody(script.body);
    setEditing(true);
  };
  const saveDraft = () => {
    const title = draftTitle.trim() || 'Untitled script';
    if (activeId && scripts.some(s => s.id === activeId)) {
      setScripts(prev => prev.map(s => s.id === activeId ? { ...s, title, body: draftBody, updated: Date.now() } : s));
    } else {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setScripts(prev => [{ id, title, body: draftBody, updated: Date.now() }, ...prev]);
      setActiveId(id);
    }
    setEditing(false);
    notify('Script saved');
  };
  const deleteScript = (id) => {
    if (!confirm('Delete this script? This cannot be undone.')) return;
    setScripts(prev => prev.filter(s => s.id !== id));
    if (activeId === id) setActiveId(null);
    notify('Script deleted');
  };
  const startPrompt = (script) => {
    setActiveId(script.id);
    setEditing(false);
    setRunning(false);
    setShowSettings(false);
    setTimeout(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, 60);
  };
  const exportScripts = () => {
    const blob = new Blob([JSON.stringify(scripts, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'proprompt-scripts.json'; a.click();
    URL.revokeObjectURL(url);
    notify('Scripts exported');
  };
  const importScripts = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (!Array.isArray(parsed)) throw new Error('Invalid file');
        const safe = parsed.filter(x => x && typeof x.title === 'string' && typeof x.body === 'string')
          .map(x => ({ id: `${Date.now()}-${Math.random().toString(36).slice(2,7)}`, title: x.title, body: x.body, updated: Date.now() }));
        setScripts(prev => [...safe, ...prev]);
        notify(`Imported ${safe.length} script${safe.length === 1 ? '' : 's'}`);
      } catch { notify('Could not import that file'); }
      e.target.value = '';
    };
    reader.readAsText(file);
  };
  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen?.();
      else await document.exitFullscreen?.();
    } catch { notify('Fullscreen is not available here'); }
  };
  const resetPrompt = () => {
    setRunning(false);
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  };
  const formatDate = (value) => new Date(value || Date.now()).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });

  return (
    <div className={`app ${dark ? 'theme-dark' : 'theme-light'}`}>
      {!activeId && !editing ? (
        <main className="home-screen">
          <header className="topbar">
            <div className="brand-mark"><span className="brand-icon"><span /></span><div><div className="brand-name">ProPrompt<span>.</span></div><div className="brand-tag">SPEAK WITH CONFIDENCE</div></div></div>
            <button className="icon-btn" aria-label="Settings" onClick={() => setShowSettings(!showSettings)}><Settings2 size={20}/></button>
          </header>
          {showSettings && <div className="quick-settings"><div><strong>Appearance</strong><span>Choose your reading environment</span></div><button className="pill-btn" onClick={() => setDark(!dark)}>{dark ? <Sun size={16}/> : <Moon size={16}/>} {dark ? 'Light mode' : 'Dark mode'}</button></div>}
          <section className="hero">
            <div className="eyebrow"><span className="live-dot"/> YOUR PERSONAL TELEPROMPTER</div>
            <h1>Your words.<br/><em>Your moment.</em></h1>
            <p>Read naturally. Stay focused. Deliver with confidence.</p>
            <button className="primary-btn new-script" onClick={openNew}><Plus size={19}/> Create a script <span className="btn-shortcut">NEW</span></button>
          </section>
          <section className="script-section">
            <div className="section-heading"><div><h2>Your scripts</h2><p>{scripts.length} {scripts.length === 1 ? 'script' : 'scripts'} saved on this device</p></div><button className="outline-btn" onClick={exportScripts}><Download size={16}/> Export</button></div>
            <div className="search-wrap"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search your scripts..." aria-label="Search scripts"/></div>
            <div className="script-list">
              {filtered.map((s, i) => (
                <article className="script-card" key={s.id}>
                  <button className="script-open" onClick={() => startPrompt(s)}>
                    <div className="script-file-icon"><FileText size={20}/></div>
                    <div className="script-info"><strong>{s.title}</strong><span>{s.body.trim().split(/\s+/).filter(Boolean).length} words <i>·</i> Edited {formatDate(s.updated)}</span><p>{s.body.replace(/\s+/g, ' ').slice(0, 82) || 'No text yet'}{s.body.length > 82 ? '…' : ''}</p></div>
                    <div className="card-play"><Play size={16} fill="currentColor"/></div>
                  </button>
                  <button className="card-more" aria-label={`Edit ${s.title}`} onClick={() => openEdit(s)}><Pencil size={15}/></button>
                </article>
              ))}
              {filtered.length === 0 && <div className="empty-state"><FileText size={26}/><strong>No scripts found</strong><span>Try another search or create a new script.</span></div>}
            </div>
            <div className="import-row"><label className="import-btn"><Upload size={16}/> Import scripts<input type="file" accept=".json,application/json" onChange={importScripts} hidden/></label><span>JSON backup · stored locally</span></div>
          </section>
          <footer className="app-footer"><span className="footer-logo">P.</span><span>Made for the moments that matter.</span><span className="version">v1.0</span></footer>
        </main>
      ) : editing ? (
        <main className="editor-screen">
          <header className="subbar"><button className="icon-btn" onClick={() => setEditing(false)}><ChevronLeft size={21}/></button><div><div className="subbar-title">{activeId ? 'Edit script' : 'New script'}</div><div className="subbar-subtitle">Make every word count</div></div><button className="text-btn" onClick={saveDraft}><Check size={16}/> Save</button></header>
          <div className="editor-content">
            <label className="field-label" htmlFor="script-title">SCRIPT TITLE</label>
            <input id="script-title" className="title-input" value={draftTitle} onChange={e => setDraftTitle(e.target.value)} placeholder="Give your script a name"/>
            <div className="editor-divider"><span>YOUR SCRIPT</span><span>{draftBody.trim().split(/\s+/).filter(Boolean).length} words</span></div>
            <textarea className="script-textarea" value={draftBody} onChange={e => setDraftBody(e.target.value)} placeholder="Start writing or paste your script here...&#10;&#10;Tip: Short sentences are easier to read while speaking." spellCheck="true"/>
            <div className="editor-tip"><span className="tip-star">✳</span><span><strong>Pro tip</strong> — Add line breaks between thoughts to make reading feel natural.</span></div>
            <button className="primary-btn full-btn" onClick={saveDraft}><Check size={18}/> Save script</button>
            {activeId && <button className="danger-btn" onClick={() => deleteScript(activeId)}><Trash2 size={16}/> Delete script</button>}
          </div>
        </main>
      ) : (
        <main className="prompt-screen">
          <header className="prompt-topbar"><button className="icon-btn" onClick={() => { setActiveId(null); setRunning(false); }}><ChevronLeft size={21}/></button><div className="prompt-heading"><span>NOW READING</span><strong>{active?.title || 'Untitled script'}</strong></div><button className="icon-btn" onClick={() => { openEdit(active); }} aria-label="Edit script"><Pencil size={17}/></button></header>
          <div className="prompt-meta"><span><Clock3 size={14}/> {Math.max(1, Math.ceil((active?.body.trim().split(/\s+/).filter(Boolean).length || 0) / 130))} min read</span><span className="meta-separator">·</span><span>{active?.body.trim().split(/\s+/).filter(Boolean).length || 0} words</span><button onClick={() => setShowTools(!showTools)}><SlidersHorizontal size={15}/> Display</button></div>
          {showTools && <div className="prompt-tools"><button onClick={() => setFontSize(v => Math.max(18, v - 2))}><Minus size={15}/> Text</button><span>{fontSize}px</span><button onClick={() => setFontSize(v => Math.min(64, v + 2))}><Plus size={15}/> Text</button><button onClick={() => setMirror(!mirror)} className={mirror ? 'selected' : ''}><FlipHorizontal2 size={16}/> Mirror</button><button onClick={toggleFullscreen}><Maximize size={16}/> Fullscreen</button></div>}
          <div className="reading-wrap">
            <div className="reading-guide"><span/><b>READING LINE</b><span/></div>
            <div className={`reading-viewport ${mirror ? 'mirrored' : ''}`} ref={scrollRef} onClick={() => setRunning(false)}>
              <div className="reading-spacer"/>
              <div className="reading-text" style={{fontSize: `${fontSize}px`, lineHeight: lineHeight}}>{active?.body || 'Your script is empty. Edit it to add your words.'}</div>
              <div className="reading-spacer bottom"/>
            </div>
            <div className="reading-fade top-fade"/><div className="reading-fade bottom-fade"/>
          </div>
          <div className="prompt-controls">
            <div className="speed-heading"><div><span>SCROLL SPEED</span><strong>{speed} <small>px / sec</small></strong></div><button className="reset-btn" onClick={resetPrompt}><RotateCcw size={15}/> Reset</button></div>
            <input className="speed-slider" type="range" min="5" max="100" value={speed} onChange={e => setSpeed(Number(e.target.value))} aria-label="Scroll speed"/>
            <div className="speed-labels"><span>Slow</span><span>Fast</span></div>
            <div className="main-controls"><button className="secondary-control" onClick={resetPrompt}><RotateCcw size={18}/><span>Restart</span></button><button className="play-control" onClick={() => setRunning(!running)}>{running ? <Pause size={21} fill="currentColor"/> : <Play size={21} fill="currentColor"/>}<span>{running ? 'Pause' : 'Start reading'}</span></button><button className="secondary-control" onClick={() => setShowSettings(!showSettings)}><Type size={18}/><span>Text</span></button></div>
            {showSettings && <div className="reading-settings"><label>Text size <strong>{fontSize}px</strong></label><input type="range" min="18" max="64" value={fontSize} onChange={e => setFontSize(Number(e.target.value))}/><label>Line spacing <strong>{lineHeight.toFixed(2)}×</strong></label><input type="range" min="1.1" max="2.1" step="0.05" value={lineHeight} onChange={e => setLineHeight(Number(e.target.value))}/><button className="pill-btn" onClick={() => setDark(!dark)}>{dark ? <Sun size={15}/> : <Moon size={15}/>} Switch to {dark ? 'light' : 'dark'} mode</button></div>}
          </div>
        </main>
      )}
      {toast && <div className="toast"><Check size={16}/>{toast}</div>}
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
