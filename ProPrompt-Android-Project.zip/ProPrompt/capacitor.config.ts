import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.proprompt.teleprompter',
  appName: 'ProPrompt',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
